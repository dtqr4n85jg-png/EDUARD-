require('dotenv').config();
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');
const config = require('./config');
const fs = require('fs');
const path = require('path');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
    ],
    partials: [Partials.Channel, Partials.Message]
});

client.commands = new Collection();
client.userBalances = new Map();

const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));
for (const file of commandFiles) {
    const command = require(`./commands/${file}`);
    if (command.name) {
        client.commands.set(command.name, command);
        if (command.aliases) {
            command.aliases.forEach(alias => client.commands.set(alias, command));
        }
    }
}

client.once('ready', () => {
    console.log(`Familien-Manager ist online ✅ – erstellt von ${config.BOT_OWNER}`);
    client.user.setActivity('!commands für Hilfe');
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.content.startsWith(config.PREFIX)) return;

    if (!config.ALLOWED_SERVERS.includes(message.guild?.id)) {
        return;
    }

    const args = message.content.slice(config.PREFIX.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    const command = client.commands.get(commandName);
    if (!command) return;

    try {
        await command.execute(message, args, client);
    } catch (error) {
        console.error(error);
        message.reply('Es gab einen Fehler beim Ausführen dieses Befehls!');
    }
});

client.on('interactionCreate', async (interaction) => {
    if (!config.ALLOWED_SERVERS.includes(interaction.guild?.id)) {
        return;
    }

    if (interaction.isButton()) {
        const buttonHandlers = {
            'casino_spin': require('./commands/casino'),
            'casino_work': require('./commands/casino'),
            'ticket_beschwerde': require('./commands/ticket'),
            'ticket_support': require('./commands/ticket'),
            'ticket_bewerben': require('./commands/ticket'),
            'close_ticket': require('./commands/ticket'),
            'embed_create': require('./commands/embed'),
            'vorschlag_create': require('./commands/vorschlag'),
        };

        for (const [prefix, handler] of Object.entries(buttonHandlers)) {
            if (interaction.customId.startsWith(prefix.split('_')[0]) || 
                interaction.customId.startsWith(prefix)) {
                await handler.handleButton(interaction, client);
                break;
            }
        }
    }

    if (interaction.isModalSubmit()) {
        const modalHandlers = {
            'vorschlag_modal': require('./commands/vorschlag'),
            'embed_modal': require('./commands/embed'),
            'bewerben_modal': require('./commands/ticket'),
        };

        for (const [modalId, handler] of Object.entries(modalHandlers)) {
            if (interaction.customId === modalId) {
                await handler.handleModal(interaction, client);
                break;
            }
        }
    }
});

client.login(process.env.DISCORD_TOKEN);
